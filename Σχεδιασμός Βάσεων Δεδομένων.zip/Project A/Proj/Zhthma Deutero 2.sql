set statistics io on

set statistics time on
checkpoint
dbcc dropcleanbuffers

Create Nonclustered Index ind5 ON movies(mid) include (title);
Create Nonclustered Index ind6 ON roles(aid);
Create Nonclustered Index ind7 ON actors(gender,aid);





/*KALO       Diko mou */
/*select distinct title
from movies,roles,actors
where movies.mid=roles.mid and roles.aid=actors.aid and ( gender='M' );*/




/*KAKO */
/*SELECT distinct title 
from movies 
join roles on movies.mid=roles.mid
 where roles.mid  in(
  select distinct roles.mid
  from roles 
  join actors on roles.aid=actors.aid
  where actors.gender='M');*/


