set statistics io on;
set statistics time on;

checkpoint;
dbcc dropcleanbuffers;

Create Nonclustered Index ind3 ON movies_genre(genre) include (mid)
Create Nonclustered Index ind4 ON movies(title)

/*
select title
 from movies, movies_genre
 where movies.mid=movies_genre.mid and genre='Adventure'
 UNION
select title
 from movies, movies_genre
 where movies.mid=movies_genre.mid and genre ='Action' */  select distinct title from movies,movies_genre where movies.mid=movies_genre.mid and (genre='Adventure' or genre ='Action');