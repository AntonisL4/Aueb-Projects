set statistics io on;
set statistics time on;

checkpoint;
dbcc dropcleanbuffers;

/*
Create Nonclustered Index ind2 ON user_movies(rating)*/
Create Nonclustered Index ind2 ON user_movies(userid,mid) include (rating);


select mid, count(rating)
 from user_movies group by mid order by mid;







select userid, count(rating)
 from user_movies group by userid order by userid;