﻿set statistics io on

set statistics time on
checkpoint
dbcc dropcleanbuffers

/* Create Nonclustered Index ind8 ON directors(did) include (firstName,lastname);
Create Nonclustered Index ind9 ON movie_directors(did,mid);
Create Nonclustered Index ind10 ON movies_genre(mid) */

/* Query που μας δίνει το ονοματεπώνυμο όλων των σκηνοθετών μαζί με το είδος και τον αριθμό των διαφορετικών 
ειδών ταινιών που έχουν σκηνοθετήσει και τα ταξινομεί αλφαβητικά με βάση το όνομα του σκηνοθέτη */


/*SELECT d.firstName as Όνομα, d.lastname as Επώνυμο, mg.genre as Είδος, count(mg.genre) as Number_of_genres_directed
from directors d, movie_directors md , movies_genre mg 
where d.did=md.did
and mg.mid = md.mid
group by d.firstName, d.lastname, mg.genre
order by d.firstName, d.lastname	*/


/*
Query που για κάθε ταινία επιστρέφει τον τίτλο και την διαφορά της μεγαλύτερης απο την μικρότερη βαθμολογία χρήστη που έχει λάβει.
Ταξινομεί με φθίνουσα σείρα με βάσει την διαφορά αλλιώς με βάσει τον τίτλο της ταινίας */

Create Nonclustered Index ind11 ON movies(mid,title);
Create Nonclustered Index ind12 ON user_movies(mid,rating);

SELECT title, (MAX(rating) - MIN(rating)) AS rating_difference
FROM movies 
join user_movies on movies.mid = user_movies.mid
GROUP BY movies.title
ORDER BY rating_difference DESC, title; 