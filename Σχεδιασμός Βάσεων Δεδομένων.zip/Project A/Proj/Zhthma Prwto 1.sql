set statistics io on;
set statistics time on;

checkpoint;
dbcc dropcleanbuffers;

Create Nonclustered Index ind1 ON movies(pyear,title); 

select title from movies where pyear between 1990 and 2000;

select pyear, title from movies where pyear between 1990 and 2000;

select title, pyear from movies where pyear between 1990 and 2000
order by pyear, title;