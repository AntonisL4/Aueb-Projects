#pragma once
#include "Image.h"
#include "vec3.h"

using namespace std;
using namespace image;
using namespace math;

	
class Filter
{
	public:
		virtual Image operator << (const Image& image) = 0;
};


class FilterLinear :public Filter
{
	public:
		Vec3<float> a;
		Vec3<float> c;
		FilterLinear(Vec3<float> a,Vec3<float> c)
		{
			this->a = a;
			this->c = c;
		}

		virtual Image operator << (const Image& image)
		{
			Image picture = image;
			Vec3<float>* temp = picture.getRawDataPtr();
			for (int i = 0; i < picture.getWidth() * picture.getHeight(); i++)
			{
				temp[i] = a * temp[i] + c;
				temp[i] = temp[i].clampToLowerBound(0);
				temp[i] = temp[i].clampToUpperBound(1.0);
			}
			return picture;
		}
};

class FilterGamma : public Filter
{
	public:
		float c;
		FilterGamma(float c)
		{
			this->c = c;
		}
		virtual Image operator << (const Image& image)
		{
			Image picture = image;
			Vec3<float>* temp = picture.getRawDataPtr();
			for (int i = 0; i < picture.getWidth() * picture.getHeight(); i++)
			{
				temp[i].r = pow(temp[i].r , c);
				temp[i].g = pow(temp[i].g, c);
				temp[i].b = pow(temp[i].b, c);
				temp[i] = temp[i].clampToLowerBound(0); //Den exei poly shmasia giati den tha kseperasei to 1
				temp[i] = temp[i].clampToUpperBound(1.0);
			}
			return picture;
		}
};