﻿#include "array2d.h"
#include "Filter.h"
#include "Image.h"
#include "vec3.h"
#include <iostream>
using namespace std;
using namespace image;


// Αντώνης Λιουσης 3120093
// Απόστολος Λάντζος 3140241

int main(int argc,char* argv[])
{
	if (argc < 5)
	{
		cout << "Den dothikan arketoi parametroi";
		return 0;
	}

	string filename = argv[argc - 1];
	Image temp;
	bool loaded = temp.load(filename,"ppm");

	if (loaded == false)
	{
		cout << "Den fortwse i photografia";
		return 0;
	}

	for (int i = 1; i < argc - 1; i++)
	{
		if (strcmp(argv[i], "-f") == 0)
		{
			if (strcmp(argv[i+1],"linear") == 0)
			{
				//Elegxous gia times twn rgb
				Vec3<float> A;
				Vec3<float> C;

				A.r = atof(argv[i + 2]);
				A.g = atof(argv[i + 3]);
				A.b = atof(argv[i + 4]);
				C.r = atof(argv[i + 5]);
				C.g = atof(argv[i + 6]);
				C.b = atof(argv[i + 7]);
				
				FilterLinear filterL(A, C);
				temp = filterL << temp;

			}
			else if (strcmp(argv[i + 1], "gamma") == 0)
			{
				float temp2 = atof(argv[i + 2]);
				FilterGamma filterG(temp2);
				temp = filterG << temp;

			}
		}
	}
	string filename2 = filename.substr(0, filename.length() - 4);
	filename2 += "_filtered.ppm";
	bool saved = temp.save(filename2, "ppm");










}