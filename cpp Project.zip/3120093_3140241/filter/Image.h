#pragma once
#include "imageio.h"
#include "../Project1/ppm.h"
#include "vec3.h"
#include <string>
#include <vector>
#include <iostream>
#include "array2d.h"

using namespace std;
using namespace math;

typedef math::Vec3<float> Color;

namespace image
{
	class Image : public Array2D<Color>, public ImageIO
	{
	public:
		bool load(const std::string& filename, const std::string& format)
		{
			string temp1 = "";
			//Vazei sto temp1 ta 3 teleutaia stoixeia tou string filename gia na doume an einai "ppm"
			for (int i = filename.length() - 3; i <= filename.length() - 1; i++)
			{
				temp1 += filename[i];
			}

			if (temp1 != format)
			{
				cout << "Wrong file format";
				return false;
			}

			float* temp;
			int w;
			int h;
			temp = ReadPPM(filename.c_str(), &w, &h); //H c_str() kanei to string -> char gia na to dwsei san orisma stin ReadPPM
			if (temp != nullptr)
			{
				buffer.resize(w * h);
				width = w;
				height = h;
				int j = 0;
				for (int i = 0; i < w * h * 3; i += 3)
				{
					buffer[j].r = temp[i];
					buffer[j].g = temp[i + 1];
					buffer[j].b = temp[i + 2];
					j++;
				}
				delete [] temp;
				cout << "File loaded successfully" << endl;
				return true;
			}
			cout << "File did not load successfully" << endl;
			return false;
		};

		bool save(const std::string& filename, const std::string& format)
		{
			if (width * height == 0)
			{
				cout << "Error";
				return false;
			}

			string temp1 = "";
			for (int i = filename.length() - 3; i <= filename.length() - 1; i++)
			{
				temp1 += filename[i];
			}
			if (temp1 != format)
			{
				cout << "Wrong file format";
				return false;
			}


			float* temp = new float[3 * width * height];
			int j = 0;
			for (int i = 0; i < width * height * 3; i += 3)
			{
				temp[i] = buffer[j].r;
				temp[i + 1] = buffer[j].g;
				temp[i + 2] = buffer[j].b;
				j++;
			}
			bool saved = WritePPM(temp, width, height, filename.c_str());
			if (saved == true)
			{
				cout << "File saved successfully" << endl;
				delete[] temp;
				return true;
			}
			else
			{
				cout << "File did not save successfully" << endl;
				delete[] temp;
				return false;
			}
		}
	};
};