
#include <vector>
#include "array2d.h"
using namespace std;

namespace math
{

	template <typename T>
	const unsigned int Array2D<T>::getWidth() const
	{
		return width;
	}

	template <typename T>
	const unsigned int Array2D<T>::getHeight() const
	{
		return height;
	}

	template <typename T>
	T* Array2D<T>::getRawDataPtr()
	{
		return &buffer[0];
	}

	template <typename T>
	void Array2D<T>::setData(const T* const& data_ptr)
	{
		if (width * height != 0)
		{
			buffer.clear();
			for (int i = 0; i < width * height; i++)
			{
				buffer.push_back(data_ptr[i]);
			}
		}
	}

	template <typename T>
	T& Array2D<T>::operator () (unsigned int x, unsigned int y)
	{
		if (x < width && y < height)
		{
			return buffer[y * width + x];
		}
		else
		{
			return buffer[0];
		}
	}
	





	template <typename T>
	Array2D<T>::Array2D(unsigned int width, unsigned int height, const T * data_ptr)
	{
		this->width = width;
		this->height = height;

		if (data_ptr == nullptr && width * height != 0)
		{
			for (int i = 0; i < width * height; i++)
			{
				T temp;
				buffer.push_back(temp);
			}

		}
		else if(width * height != 0)
		{
			for (int i = 0; i < width * height; i++)
			{
				buffer.push_back(data_ptr[i]); 
			}
		}
	}

	template <typename T>
	Array2D<T>::Array2D(const Array2D & src)
	{
		width = src.width;
		height = src.height;
		buffer.clear();
		for (auto it = src.buffer.begin(); it != src.buffer.end(); it++)
		{
			buffer.push_back(*it);
		}
	}

	template <typename T>
	Array2D<T>::~Array2D()
	{
	}

	template <typename T>
	Array2D<T>& Array2D<T>::operator = (const Array2D<T> & right)
	{
		if (this == &right)
		{
			return *this;
		}
		width = right.width;
		height = right.height;
		buffer.clear();
		if (right.buffer.size() == 0)
		{
			buffer.clear();
			//buffer.resize(right.width * right.height);
				for (auto it = buffer.begin(); it != buffer.end(); it++)
				{
					buffer.push_back(0);
				}
		}
		else {
			for (auto it = right.buffer.begin(); it != right.buffer.end(); it++)
			{
				buffer.push_back(*it);
			}
		}
		return *this;
	}
}