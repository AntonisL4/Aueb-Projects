#include "ppm.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;


namespace image
{

	float* ReadPPM(const char* filename, int* w, int* h)
	{
		ifstream file = ifstream(filename, ios_base::in | ios_base::binary);
		if (file)
		{
			string type;
			int width;
			int height;
			int colourValue;
			file >> type; 
			if (type != "P6")
			{
				cout << "Wrong image format";
				return nullptr;
			}
			file >> width;
			file >> height;
			file >> colourValue;
			if (width <= 0 || height <= 0 || colourValue != 255)
			{
				cout << "Wrong image parameters";
				return nullptr;
			}
			//Ftiaxnei pinaka diastasewn ypsos*platos*3 pou apothikeuei ana 3 theseis ta xrwmata tou kathe pixel
			float *stored = new float[3.0 * width * height];
			*w = width;
			*h = height;
			unsigned char colour;
			file.get(); //Parakamptei tin allagi grammis meta ta text(gia na min thesei to /n ws R)
			for (int i = 0; i < width * height * 3; i += 3)
			{
				file.read((char*)&colour, sizeof(unsigned char));
				stored[i] = colour / 255.0;
				file.read((char*)&colour, sizeof(unsigned char));
				stored[i + 1] = colour / 255.0;
				file.read((char*)&colour, sizeof(unsigned char));
				stored[i + 2] = colour / 255.0;
			}
			file.close();
			return stored;
		}
		else {
			cout << "Error when reading the file.";
			return nullptr;
		}	
	}
	


	bool WritePPM(const float* data, int w, int h, const char* filename)
	{
		if (data == nullptr)
		{
			cout << "Error during saving";
			return false;
		}

		ofstream file = ofstream(filename, ios_base::out | ios_base::binary);
		if (file)
		{
			string type = "P6";
			int colourValue = 255;
			file << type << endl;
			file << w << endl;
			file << h << endl;
			file << colourValue << endl;
			unsigned char value;
			for (int i = 0; i < w * h*3; i += 3)
			{
				value = data[i] * 255;
				file.write((char*)&value, sizeof(unsigned char));
				value = data[i + 1] * 255;
				file.write((char*)&value, sizeof(unsigned char));
				value = data[i + 2] * 255;
				file.write((char*)&value, sizeof(unsigned char));
			}
			file.close();
			return true;
		}
		else
		{
			cout << "Error during saving";
			return false;
		}
	}

}