package katanemimena;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ThreadBroker extends Thread
{
    private int myhash;
    private Socket clientSocket;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private ArrayList<NodeConnectionInfo> registeredPublishers;

    public ThreadBroker(Socket clientSocket, ArrayList<NodeConnectionInfo> registeredPublishers, int myhash)
    {
        this.clientSocket = clientSocket;
        this.registeredPublishers = registeredPublishers;
        this.myhash = myhash;
    }

    @Override
    public void run()
    {
        try {
            
            // stream gia in kai out
            out = new ObjectOutputStream( clientSocket.getOutputStream() );
            in = new ObjectInputStream(clientSocket.getInputStream());
                
            String artistName = (String) in.readObject();

            // koitazei na dei an ypostirizei to kallitexni
            HashFunction hf = new HashFunction( Broker.brokers.size() );
            int artistHash = hf.calculateHash(artistName);
            
            // an tairiazei to hash
            if(artistHash == myhash)
            {
                out.writeBoolean(true);
                out.flush();
                
                NodeConnectionInfo publisher = null;
                
                // psaxnei ton publisher pou ton ypostirzei
                for (NodeConnectionInfo registeredPublisher : registeredPublishers)
                {
                    for (MusicFile musicFile : registeredPublisher.filesList)
                    {
                        if( musicFile.artistName.equals( artistName ) )
                        {
                            publisher = registeredPublisher;
                            break;
                        }
                    }
                }
                
                String songName = (String) in.readObject();
                
                // sindesi kai metafora tou tragoudiou
                NodesSockets publisherCon = new NodesSockets( publisher );
                
                // sindesi kai apostoli twn stoixeiwn tou tragoudiou
                publisherCon.connect();
                publisherCon.sendObject("get");
                publisherCon.sendObject( artistName );
                publisherCon.sendObject( songName );
                
                boolean ok = publisherCon.in.readBoolean();
                
                // enimeronei kai ton consumer gia to apotelesma
                out.writeBoolean(ok);
                
                if(ok == true)
                {
                    
                    long lengthRead;
                    long totalLengthSent = 0;

                    try {

                        String topic;
                        Value value;
                        
                        do{
                            byte [] bytes = new byte[256];

                            // diavasma tou chunk apo to arxeio
                            topic = (String) publisherCon.receiveObject();
                            value = (Value) publisherCon.receiveObject();

                            lengthRead = value.musicFile.musicFileExtract.length;
                            totalLengthSent = totalLengthSent + lengthRead;

                            System.out.println("Received chunk of "+value.musicFile.trackName+" from publisher");
                            System.out.println("Sending chunk of "+value.musicFile.trackName+" to consumer");
                            
                            // to proothei ston consumer
                            out.writeObject(topic);
                            out.writeObject(value);


                            // Oso den exei diavasei olo to arxeio
                        }while( totalLengthSent < value.musicFile.fileLength );
                        
                    }
                    catch (FileNotFoundException ex)
                    {
                        Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex)
                    {
                        Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }                    
                
                publisherCon.disconnect();
            }
            else
            {
                out.writeBoolean(false);
                
                // vriskei poios broker to ypostirizei
                for (NodeConnectionInfo broker : Broker.brokers)
                {
                    if( broker.hash == artistHash )
                    {
                        out.writeObject( broker );
                        out.flush();
                        break;
                    }
                }

            }
            
        }
        catch (IOException ex)
        {
            Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally
        {
            try {
                in.close();
                out.close();
                clientSocket.close();
            } catch (IOException ex) {
                Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    
    
    
}
