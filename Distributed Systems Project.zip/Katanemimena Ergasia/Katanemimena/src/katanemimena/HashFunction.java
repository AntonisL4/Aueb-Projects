package katanemimena;// Klassi pou exei synartiseis gia to hash

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashFunction
{
    private final int modNumber;

    public HashFunction(int modNumber) {
        this.modNumber = modNumber;
    }
    
    public int calculateHash(String str)
    {
        BigInteger bi = hash(str);
        
        // An einai arnitiko to kanei thetiko
        int h = bi.intValue() > 0 ? bi.intValue() : -bi.intValue();
        
        // Kanei mod me to megisto arithmo. Diladi to plithos twn broker
        return h % modNumber;
    }
    
    // H synartisi pou ousiastika kanei to hash
    private BigInteger hash(String str) 
    { 
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1"); 
  
            // Ypologismos tou pinaka byte pou bgainei apo to String
            byte[] stringBytes = md.digest(str.getBytes()); 
  
            // Apodosi tou md se megalo akeraio
            BigInteger bigNum = new BigInteger(1, stringBytes); 
  
            return bigNum;
        }  
        catch (NoSuchAlgorithmException e)
        { 
            throw new RuntimeException(e); 
        } 
    } 
}
