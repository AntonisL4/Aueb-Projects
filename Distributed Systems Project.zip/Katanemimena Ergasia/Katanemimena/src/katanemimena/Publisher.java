package katanemimena;

import com.mpatric.mp3agic.ID3v1;
import com.mpatric.mp3agic.ID3v2;
import com.mpatric.mp3agic.InvalidDataException;
import com.mpatric.mp3agic.Mp3File;
import com.mpatric.mp3agic.UnsupportedTagException;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Publisher implements Node
{
    private boolean active;
    private ServerSocket ss;
    private int port;
    
    private ArrayList<MusicFile> songs;
    private String path;

    public Publisher(int port, ArrayList<NodeConnectionInfo> brokers, String path)
    {
        Publisher.brokers.addAll(brokers);
        
        this.songs = new ArrayList<MusicFile>();
        
        this.port = port;
        this.path = path;
        this.active = true;
    }
    
    @Override
    public void init()
    {
        try {
            
            // vriskei ta tragoudia
            listFiles(new File( path ), songs);
            
            for (MusicFile song : songs) {
                System.out.println(song.artistName+" "+song.trackName);
            }
            
            System.out.println("Total songs read "+songs.size());
            
            // syndesi
            connect();
            
            System.out.println("katanemimena.Publisher read to accept connections");
            
            do{
            
                // Molis syndethei neos client
                Socket newClient = ss.accept();
                
                // ftianei kai ena nima
                ThreadPublisher threadPublisher = new ThreadPublisher(newClient, songs);
                threadPublisher.start();
                
                
            }while( active == true );
            
            
            // aposyndesi
            disconnect();
        }
        catch (IOException ex)
        {
            Logger.getLogger(Publisher.class.getName()).log(Level.SEVERE, null, ex);
        }
                
                
    }

    
    
    @Override
    public ArrayList<NodeConnectionInfo> getBrokers()
    {
        return brokers;
    }

    @Override
    public void connect()
    {
        try {
            
            // Anoigei socket gia na dexetai syndeseis apo tous broker kai ta nimata tous
            ss = new ServerSocket(port);
            
        } catch (IOException ex) {
            Logger.getLogger(Publisher.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void disconnect()
    {
        try {
            
            // Kleinei to server socket
            ss.close();
            
        } catch (IOException ex) {
            Logger.getLogger(Publisher.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    public void listFiles(File folder, ArrayList<MusicFile> songsList)
    {
        for (final File f : folder.listFiles())
        {

            if (f.isDirectory()) {
                listFiles(f, songsList);
            }

            if (f.isFile() && !f.isHidden())
            {
                try {
                    
                    // anoigei gia na parei tis plirofories tou
                    Mp3File mp3file = new Mp3File( f.getAbsolutePath() );
                    
                    String trackName = null;
                    String artistName = null;
                    String albumName = null;
                    String genre = null;
                    
                    
                    if (mp3file.hasId3v1Tag())
                    {
                        ID3v1 id3v1Tag = mp3file.getId3v1Tag();
                        
                        if(id3v1Tag.getTitle() != null && !id3v1Tag.getTitle().equals(""))
                            trackName = id3v1Tag.getTitle();

                        if(id3v1Tag.getArtist()!= null && !id3v1Tag.getArtist().equals(""))
                            artistName = id3v1Tag.getArtist();

                        if(id3v1Tag.getAlbum()!= null && !id3v1Tag.getAlbum().equals(""))
                            albumName = id3v1Tag.getAlbum();
                        
                        if(id3v1Tag.getGenreDescription()!= null && !id3v1Tag.getGenreDescription().equals(""))
                            genre = id3v1Tag.getGenreDescription();

                    }
                    
                    if (mp3file.hasId3v2Tag())
                    {
                        ID3v2 id3v1Tag = mp3file.getId3v2Tag();
                        
                        if(id3v1Tag.getTitle() != null && !id3v1Tag.getTitle().equals(""))
                            trackName = id3v1Tag.getTitle();

                        if(id3v1Tag.getArtist()!= null && !id3v1Tag.getArtist().equals(""))
                            artistName = id3v1Tag.getArtist();

                        if(id3v1Tag.getAlbum()!= null && !id3v1Tag.getAlbum().equals(""))
                            albumName = id3v1Tag.getAlbum();
                        
                        if(id3v1Tag.getGenreDescription()!= null && !id3v1Tag.getGenreDescription().equals(""))
                            genre = id3v1Tag.getGenreDescription();

                    }
                    
                    if(trackName == null)
                    {
                        trackName = f.getName().replace(".mp3", "");
                    }
                    
                    MusicFile musicFile = new MusicFile(trackName, artistName, albumName, genre, f.getAbsolutePath(), f.length());
                    songsList.add(musicFile);
                    
                } catch (IOException ex) {
                    Logger.getLogger(Publisher.class.getName()).log(Level.SEVERE, null, ex);
                } catch (UnsupportedTagException ex) {
                    Logger.getLogger(Publisher.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InvalidDataException ex) {
                    Logger.getLogger(Publisher.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
    }
    
    public static void main(String[] args)
    {
        ArrayList<NodeConnectionInfo> brokers = new ArrayList<>();
        brokers.add(new NodeConnectionInfo(0, "127.0.0.1", 4000));
        brokers.add(new NodeConnectionInfo(1, "127.0.0.1", 4001));
//        brokers.add(new katanemimena.NodeConnectionInfo(2, "127.0.0.1", 4002));
        
        
        Publisher publisher = new Publisher(5000, brokers, "dataset2/dataset2");
        
        publisher.init();
    }
}
