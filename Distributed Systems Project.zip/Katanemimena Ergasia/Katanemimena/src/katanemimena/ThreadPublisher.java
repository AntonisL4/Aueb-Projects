package katanemimena;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

// Nima tou publisher gia tis eiserxomenes sindeseis
public class ThreadPublisher extends Thread
{
    private Socket clientSocket;
    private ArrayList<MusicFile> songs;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    
    public ThreadPublisher(Socket clientSocket, ArrayList<MusicFile> songs)
    {
        this.clientSocket = clientSocket;
        this.songs = songs;
    }


    @Override
    public void run()
    {

        try {
            
            // stream gia in kai out
            out = new ObjectOutputStream( clientSocket.getOutputStream() );
            in = new ObjectInputStream(clientSocket.getInputStream());
            
            do{
                
                String aitisi = (String) in.readObject();
                
                if(aitisi.equals("update"))         // enimerwnei gia ta hash
                {
                    // dexetai tin lista me ta hash twn broker
                    ArrayList<NodeConnectionInfo> nci = (ArrayList<NodeConnectionInfo>) in.readObject();
                    Publisher.brokers.clear();
                    Publisher.brokers.addAll(nci);
                    
                    // stelnei tin diki tou lista
                    out.writeObject( songs );
                    
                    System.out.println("katanemimena.Publisher updated");
                }
                else if(aitisi.equals("search"))         // anazita to tragoudi
                {
                    boolean flag = false;
                    String artistName = (String) in.readObject();
                    
                    System.out.print("katanemimena.Publisher is searching for "+artistName);
                    
                    for (MusicFile musicFile : songs)
                    {
                        if( musicFile.artistName.equals(artistName) == true )
                        {
                            flag = true;
                            break;
                        }
                    }
                    
                    // stelnei true/false analoga me to an vrethike i oxi
                    out.writeBoolean( flag );
                    out.flush();
                    
                    System.out.println(flag ? " found" : " not found");
                }
                else if( aitisi.equals("get") )     // stelnei to tragoudi
                {
                    boolean flag = false;
                    MusicFile mf = null;
                    String artistName  = (String) in.readObject();
                    String trackName   = (String) in.readObject();
                    
                    System.out.print("katanemimena.Broker is pulling "+artistName+" "+trackName+" ...");
                    
                    for (MusicFile musicFile : songs)
                    {
                        if( musicFile.artistName.equals(artistName) == true )
                        {
                            if( musicFile.trackName.equals(trackName) == true )
                            {
                                flag = true;
                                mf = musicFile;
                                break;
                            }
                        }
                    }
                    
                    // stelnei true/false analoga me to an vrethike i oxi
                    out.writeBoolean( flag );
                    out.flush();
                    
                    if( flag == true )              // an to exei vrei
                    {
                        sendFileToBroker(mf);
                        System.out.println("completed");
                    }
                    else
                    {
                        System.out.println("failed to find");
                    }
                    
                    break;
                }
                
            }while( true );
            
        }
        catch (IOException ex)
        {
            Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally
        {
            try {
                in.close();
                out.close();
                clientSocket.close();
            } catch (IOException ex) {
                Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
    }
    
    
    private void push(String artistName, Value value)
    {
        try
        {
            out.writeObject(artistName);
            out.writeObject(value);
            out.flush();
            
        }
        catch (IOException ex)
        {
            Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    private void sendFileToBroker(MusicFile mf)
    {
        long lengthRead;
        long totalLengthSent = 0;
        InputStream inputStream = null;
        
        try {
            
            inputStream = new FileInputStream( mf.path );
            
            do{
                byte [] bytes = new byte[256];
                
                // diavasma tou chunk apo to arxeio
                lengthRead = inputStream.read(bytes);
                
                totalLengthSent = totalLengthSent + lengthRead;
                
                mf.setMusicFileExtract( bytes );
                
                System.out.println("Sending chunk of "+mf.trackName+" to broker");
                
                // ftiaxnei to katanemimena.Value
                Value v = new Value(mf);
                
                push(mf.artistName, v);
                
                
                // Oso den exei diavasei olo to arxeio
            }while( totalLengthSent < mf.fileLength );
            
            
        }
        catch (FileNotFoundException ex)
        {
            Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex)
        {
            Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            try {
                inputStream.close();
            } catch (IOException ex) {
                Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
}
