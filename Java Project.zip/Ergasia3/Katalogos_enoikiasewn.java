
import java.util.ArrayList;


public class Katalogos_enoikiasewn extends ArrayList<Enoikiasi>{
    
}
