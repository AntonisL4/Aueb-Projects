



public class Proion {
    
    protected double kostos_ana_imera;
    protected String katigoria;
    protected String titlos;
    protected int etosParagogis;
    protected String etairiaParagogis;

    public Proion(String titlos, double kostos_ana_imera, String katigoria, int etosParagogis, String etairiaParagogis) {
        this.kostos_ana_imera = kostos_ana_imera;
        this.katigoria = katigoria;
        this.etosParagogis = etosParagogis;
        this.etairiaParagogis = etairiaParagogis;
        this.titlos = titlos;
    }



    @Override
    public String toString() {
        
        String s = "Titlos: "+ titlos+"\n";
                s += "Katigoria: "+katigoria+"\n";
                s += "Etos Paragogis: "+etosParagogis+"\n";
                s += "Etairia Paragogis: "+etairiaParagogis+"\n";
        
        return s; 
    }
    
    public String toFile() {
        
        String s = "\t\tTITLE: "+ titlos+"\n";
                s += "\t\tCATEGORY: "+katigoria+"\n";
                s += "\t\tYEAR: "+etosParagogis+"\n";
                s += "\t\tCOMPANY: "+etairiaParagogis+"\n";
                s += "\t\tCOST: "+kostos_ana_imera+"\n";
        
        return s; 
    }

    public double getKostos_ana_imera() {
        return kostos_ana_imera;
    }

    public String getKatigoria() {
        return katigoria;
    }

    public int getEtosParagogis() {
        return etosParagogis;
    }

    public String getEtairiaParagogis() {
        return etairiaParagogis;
    }

    public String getTitlos() {
        return titlos;
    }
    
    
}
