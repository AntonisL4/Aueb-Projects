public class Games extends Proion {

    protected String console;


    public Games(String titlos, String console,double kostos_ana_imera, String katigoria, int etosParagogis, String etairiaParagogis) {
        super(titlos, kostos_ana_imera, katigoria, etosParagogis, etairiaParagogis);
        this.console = console;

    }

    public String getConsole() {
        return console;
    }

    @Override
    public String toString() {
        String s = super.toString();
        s += "Konsola: "+console+"\n";
        return s;
    }

    @Override
    public String toFile() {
        String s = super.toFile();
        s += "\t\tITEM_TYPE: game\n";
        s += "\t\tPLATFORM: "+console+"\n";
        return s;
    }
    
    
}