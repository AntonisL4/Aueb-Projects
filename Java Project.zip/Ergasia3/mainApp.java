
import java.util.Scanner;


public class mainApp {

    Katalogos_proiontwn proionta = new Katalogos_proiontwn();
    Katalogos_enoikiasewn enoikiaseis = new Katalogos_enoikiasewn();
    
    public static void main(String[] args) {
        
        mainApp katastima = new mainApp();
        
        /* Dimourgia proiontwn */
        DVD Sonic_the_Hedgehog = new DVD("Sonic the Hedgehog", true, "Patrick Casey", " Jim Carrey, James Marsden, Neal McDonough", "Jeff Fowler", 0.50, "Animation, Action, Adventure", 2019, "Animation, Action, Adventure");
        DVD Tolkien = new DVD("Tolkien",true, " David Gleeson, Stephen Beresford", " Lily Collins, Nicholas Hoult, Laura Donnelly", "Dome Karukoski", 0.50, "Biography, Drama", 2019, " Fox Searchlight Pictures, Chernin Entertainment");
        DVD Platoon= new DVD("Platoon",false," Oliver Stone"," Charlie Sheen, Tom Berenger, Willem Dafoe","Oliver Stone",0.50," Drama, War",1986," Hemdale, Cinema 86");
        DVD Rocky= new DVD ("Rocky",false,"Sylvester Stallone","Sylvester Stallone, Talia Shire, Burt Young","John G. Avildsen",0.50," Drama, Sport",1976," Chartoff-Winkler Productions");


        Blue_ray Toy_Story_4 = new Blue_ray("Toy Story 4", " John Lasseter", " Christina Hendricks, Patricia Arquette, Keanu Reeves", "Josh Cooley", 0.50, " Animation, Adventure, Comedy", 2019, " Pixar Animation Studios, Walt Disney Pictures");
        Blue_ray Avengers_Endgame = new Blue_ray("Avengers Endgame","Christopher Markus, Stephen McFeely", " Robert Downey Jr., Chris Evans, Mark Ruffalo", "Anthony Russo, Joe Russo", 0.50, " Action, Adventure, Fantasy", 2019, " Marvel Studios, Walt Disney");

        Games Days_Gone = new Games("Days Gone","Play Station",0.50,"Action Adventure",2018,"Bend Studio");
        Games Sniper_Elite_V2_Remastered = new Games("Sniper Elite V2 Remastered","Play Station",0.50,"Action",2019,"Rebelion");

        Games The_Elder_Scrolls_Online_Elsweyr = new Games("The Elder Scrolls Online Elsweyr","Xbox",0.50,"Role playing (RPG)",2019,"Bethesda");
        Games One_Piece_World_Seeker = new Games("One Piece World Seeker","Xbox",0.50,"Action Adventure",2019,"Bandai, Namco");

        Games Super_Mario_Party = new Games("Super Mario Party","Nintendo",0.50,"Action Adventure",2018,"Nintendo");
        Games Donkey_Kong_Country_Tropical_Freeze = new Games("Donkey Kong Country Tropical Freeze","Nintendo",0.50,"Action Adventure",2018,"Nintendo");
        
        // Prosthetoume ston katalogo (arraylist)
//        katastima.proionta.add( new Pair(Sonic_the_Hedgehog, 5) );
//        katastima.proionta.add( new Pair(Tolkien, 5) );
//        katastima.proionta.add( new Pair(Platoon, 5) );
//        katastima.proionta.add( new Pair(Rocky, 5) );
//        katastima.proionta.add( new Pair(Toy_Story_4, 5) );
//        katastima.proionta.add( new Pair(Avengers_Endgame, 5) );
//        katastima.proionta.add( new Pair(Days_Gone, 5) );
//        katastima.proionta.add( new Pair(Sniper_Elite_V2_Remastered, 5) );
//        katastima.proionta.add( new Pair(The_Elder_Scrolls_Online_Elsweyr, 5) );
//        katastima.proionta.add( new Pair(One_Piece_World_Seeker, 5) );
//        katastima.proionta.add( new Pair(Super_Mario_Party, 5) );
//        katastima.proionta.add( new Pair(Donkey_Kong_Country_Tropical_Freeze, 5) );
        
        
        // Xekinaw to menou
        katastima.menu();
    }
    
    public Enoikiasi menuStoixeiaEnoikiasis(Scanner in, Proion proion)
    {
        System.out.print("Onoma Epwnymo: ");
        in.nextLine();
        String onoma_epwnymo = in.nextLine();
        System.out.print("Tilefwono: ");
        String thlefwno = in.nextLine();
        
        System.out.print("Meres enoikiasis: ");
        int meres_enoikiasis = in.nextInt();
        
        Enoikiasi en = new Enoikiasi(proion, onoma_epwnymo, thlefwno, meres_enoikiasis);
        return en;
    }
    
    public void menuEpiskopisiTainiwn(Scanner in)
    {
        int choice = 0;
        int i;
        
        do{
            System.out.println("---------------------------------");
            System.out.println("0. Episkopisi DVD");
            System.out.println("1. Episkopisi BlueRay");
            System.out.println("2. Epistrofi");

            
            choice = in.nextInt();
            System.out.println("---------------------------------");
            
            if( choice == 0 ){
                i = 0;
                for (Pair pair : proionta) {
                    
                    Proion p = pair.proion;
                    if( p.getClass() == DVD.class && pair.apothema > 0 ){
                        System.out.println( i + " " + p.getTitlos() );
                        i++;
                    }
                }

                System.out.println("---------------------------------");
                System.out.println("Dialexe arithmo tainias");
                choice = in.nextInt();
                System.out.println("---------------------------------");
                
                Pair epilemeno = null;
                if( choice >= 0 && choice < i )
                {
                    i = 0;
                    for (Pair pair : proionta) {

                        if(choice == i){
                            epilemeno = pair;
                            break;
                        }
                        
                        Proion p = pair.proion;
                        if( p.getClass() == DVD.class && pair.apothema > 0 ){
                            i++;
                        }
                    }
                    
                    System.out.println(epilemeno.proion);
                    Enoikiasi e = menuStoixeiaEnoikiasis(in, epilemeno.proion);
                    enoikiaseis.add(e);
                    
                    epilemeno.apothema--;
                    
                    System.out.println("Kostos enoikiasis "+e.getKostos());
                    System.out.println("---------------------------------");
                    break;
                }
                else
                {
                    System.out.println("Lathos epilogi");
                }
            }
            else if( choice == 1 ){
                
                i = 0;
                for (Pair pair : proionta) {
                    
                    Proion p = pair.proion;
                    if( p.getClass() == Blue_ray.class && pair.apothema > 0 ){
                        System.out.println( i + " " + p.getTitlos() );
                        i++;
                    }
                }

                System.out.println("---------------------------------");
                System.out.println("Dialexe arithmo tainias");
                choice = in.nextInt();
                System.out.println("---------------------------------");
                
                Pair epilemeno = null;
                if( choice >= 0 && choice < i )
                {
                    i = 0;
                    for (Pair pair : proionta) {

                        if(choice == i){
                            epilemeno = pair;
                            break;
                        }
                        
                        Proion p = pair.proion;
                        if( p.getClass() == Blue_ray.class && pair.apothema > 0 ){
                            i++;
                        }
                    }
                    
                    System.out.println(epilemeno.proion);
                    Enoikiasi e = menuStoixeiaEnoikiasis(in, epilemeno.proion);
                    enoikiaseis.add(e);
                    
                    epilemeno.apothema--;
                    
                    System.out.println("Kostos enoikiasis "+e.getKostos());
                    System.out.println("---------------------------------");
                    break;
                }
                else
                {
                    System.out.println("Lathos epilogi");
                }
            }
            
        }while( choice != 2 );
    }
    
    public void menuEpiskopisiGames(Scanner in)
    {
        int choice = 0;
        int i;

        System.out.println("---------------------------------");

        i = 0;
        for (Pair pair : proionta) {

            Proion p = pair.proion;
            if( p.getClass() == Games.class && pair.apothema > 0 ){
                System.out.println( i + " " + p.getTitlos() );
                i++;
            }
        }

        System.out.println("---------------------------------");
        System.out.println("Dialexe arithmo game");
        choice = in.nextInt();
        System.out.println("---------------------------------");

        Pair epilemeno = null;
        if( choice >= 0 && choice < i )
        {
            i = 0;
            for (Pair pair : proionta) {

                if(choice == i){
                    epilemeno = pair;
                    break;
                }

                Proion p = pair.proion;
                if( p.getClass() == Games.class && pair.apothema > 0 ){
                    i++;
                }
            }

            System.out.println(epilemeno.proion);
            Enoikiasi e = menuStoixeiaEnoikiasis(in, epilemeno.proion);
            enoikiaseis.add(e);

            epilemeno.apothema--;

            System.out.println("Kostos enoikiasis "+e.getKostos());
            System.out.println("---------------------------------");
        }
        else
        {
            System.out.println("Lathos epilogi");
            System.out.println("---------------------------------");
        }

    }
    
    public void menuEpiskopisiEnoikiasewn(Scanner in)
    {
        Enoikiasi temp = null;
        
        if( enoikiaseis.isEmpty() ){
            System.out.println("---------------------------------");
            System.out.println("O katalogos einai adeios");
            System.out.println("---------------------------------");
            return ;
        }
        
        for (Enoikiasi e : enoikiaseis) {

            System.out.println( e.getKodikos() );
        }

        System.out.println("---------------------------------");
        System.out.print("Dialexe kodikos enoikiasis: ");
        int kod = in.nextInt();

        boolean found = false;
        
        for (Enoikiasi e : enoikiaseis) {

            if( kod == e.getKodikos() ){
                found = true;
                temp = e;
                break;
            }
        }
        
        if( found == false ){
            System.out.println("---------------------------------");
            System.out.println("Lathos kodikos enoikiasis");
            System.out.println("---------------------------------");
        }
        else{
            System.out.println( temp );

            System.out.println("---------------------------------");
            System.out.print("Thes na to epistrepseis ? (y/n) ");
            in.nextLine();
            String answer = in.nextLine();
            System.out.println("---------------------------------");
            
            if( answer.equals("y") ){
                
                System.out.print("Dwse synolikes imeres kratisis: ");
                int telikes_imeres = in.nextInt();
                
                System.out.println("To epipleon kostos einai : "+temp.kathisterisi(telikes_imeres));
                System.out.println("Synoliko kostos: "+temp.getKostos());
                System.out.println("---------------------------------");
                
                enoikiaseis.remove(temp);
                Proion p = temp.getProion();
                
                for (Pair pair : proionta) {
                    
                    if( pair.proion == p ){
                        pair.apothema++;
                        break;
                    }
                }
                
                
                
            }
        }
    }
    
    public void menu()
    {
        int choice = 0;
        Scanner in = new Scanner(System.in);
        
        Loader loader = new Loader(enoikiaseis, proionta);
        loader.loadItems("items.txt");
        loader.loadRents("rents.txt");
        
        do{
            System.out.println("0. Episkopisi Tainiwn");
            System.out.println("1. Episkopisi Games");
            System.out.println("2. Episkopisi Enoikiasewn");
            System.out.println("3. Exit");
            
            choice = in.nextInt();
            
            if( choice == 0 )
                menuEpiskopisiTainiwn(in);
            else if( choice == 1 )
                menuEpiskopisiGames(in);
            else if( choice == 2 )
                menuEpiskopisiEnoikiasewn(in);
            
        }while( choice != 3 );
        
        Saver saver = new Saver(enoikiaseis, proionta);
        saver.saveItems("items.txt");
        saver.saveRents("rents.txt");
        
      
    }
}

