
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Enoikiasi {

    private static int auxon_arithmos = 1;

    private int kodikos;
    private Proion proion;
    private String onoma_epwnymo;
    private String thlefwno;
    private String mera_enoikiasis;
    private int meres_enoikiasis;
    private double kostos;
    private double epipleon_kostos;

    private Date imerominia;
    
    // Kataskeuastis gia ton loader
    public Enoikiasi(Proion proion, String onoma_epwnymo,String thlefwno,int meres_enoikiasis, Date imerominia, double cost)
    {
        this.imerominia = imerominia;
        this.proion = proion;
        this.onoma_epwnymo = onoma_epwnymo;
        this.thlefwno=thlefwno;
        this.mera_enoikiasis=""+imerominia.getDate();
        this.meres_enoikiasis=meres_enoikiasis;
        this.kostos = cost;
        
        kodikos = auxon_arithmos;
        auxon_arithmos++;
    }
    
    public Enoikiasi(Proion proion, String onoma_epwnymo,String thlefwno,int meres_enoikiasis) {

        Date simera = new Date();
        simera.setHours(0);
        
        this.imerominia = simera;
        this.proion = proion;
        this.onoma_epwnymo = onoma_epwnymo;
        this.thlefwno=thlefwno;
        this.mera_enoikiasis=""+simera.getDate();
        this.meres_enoikiasis=meres_enoikiasis;

        // Ypoologismos kostous
        int meres = 7;
        if( this.proion.getClass() == DVD.class )
        {
            DVD dvdA = (DVD) this.proion;
            if (dvdA.getneas_kukloforias() == true){
                kostos = proion.getKostos_ana_imera()*meres_enoikiasis;
                epipleon_kostos = (meres_enoikiasis-1)*proion.getKostos_ana_imera();
            }
            else{
                kostos = 7*this.proion.getKostos_ana_imera();
                if ((meres_enoikiasis-7) > 0 ){
                    epipleon_kostos = (meres_enoikiasis-7)*proion.getKostos_ana_imera();
                }
                else{
                    epipleon_kostos = 0;
                }
                
                this.meres_enoikiasis = 7;
            }
        }
        else if(this.proion.getClass() == Blue_ray.class )
        {
            kostos = proion.getKostos_ana_imera();
            epipleon_kostos = (meres_enoikiasis-1)*proion.getKostos_ana_imera();
        }
        else if(this.proion.getClass() == Games.class )
        {
            kostos = 7*proion.getKostos_ana_imera();
            if ((meres_enoikiasis-7) > 0 ){
                epipleon_kostos = (meres_enoikiasis-7)*proion.getKostos_ana_imera();
            }
            else{
                epipleon_kostos = 0;
            }
            this.meres_enoikiasis = 7;
        }
        kodikos = auxon_arithmos;
        auxon_arithmos++;
    }


    public int getKodikos() {
        return kodikos;
    }

    public Proion getProion() {
        return proion;
    }

    public String getOnoma_epwnymo() {
        return onoma_epwnymo;
    }

    public String getThlefwno() {
        return thlefwno;
    }

    public String getMera_enoikiasis() {
        return mera_enoikiasis;
    }

    public int getMeres_enoikiasis() {
        return meres_enoikiasis;
    }

    public double getKostos() {
        return kostos+epipleon_kostos;
    }

    public double getEpipleon_kostos() {
        return epipleon_kostos;
    }
    
    public double kathisterisi(int telikes_imeres)
    {
        if( meres_enoikiasis >= telikes_imeres ){
            return 0.0;
        }
        else
        {
            
            if( this.proion.getClass() == DVD.class )
            {
                DVD dvdA = (DVD) this.proion;
                if (dvdA.getneas_kukloforias() == true){
                    epipleon_kostos = (telikes_imeres-meres_enoikiasis)*proion.getKostos_ana_imera();
                }
                else{
                    if ((telikes_imeres-7) > 0 ){
                        epipleon_kostos = (telikes_imeres-7)*proion.getKostos_ana_imera();
                    }
                    else{
                        epipleon_kostos = 0;
                    }
                }
            }
            else if(this.proion.getClass() == Blue_ray.class )
            {
                epipleon_kostos = (telikes_imeres-meres_enoikiasis)*proion.getKostos_ana_imera();
            }
            else if(this.proion.getClass() == Games.class )
            {
                if ((telikes_imeres-7) > 0 ){
                    epipleon_kostos = (telikes_imeres-7)*proion.getKostos_ana_imera();
                }
                else{
                    epipleon_kostos = 0;
                }
            }
            
            return epipleon_kostos;
        }
    }

    @Override
    public String toString() {
        return "Enoikiasi{" +
                "kodikos=" + kodikos +
                ", proion=" + proion +
                ", onoma_epwnymo='" + onoma_epwnymo + '\'' +
                ", thlefwno='" + thlefwno + '\'' +
                ", mera_enoikiasis='" + mera_enoikiasis + '\'' +
                ", meres_enoikiasis=" + meres_enoikiasis +
                ", kostos=" + kostos +
                ", epipleon_kostos=" + epipleon_kostos +
                '}';
    }

    String toFile() {
        
        String s = "";
        
        if( proion instanceof Tainia){
            s += "\t\tITEM_TYPE: movie\n";
            if( proion instanceof DVD)
                s += "\t\tSUB_TYPE: DVD\n";
            else
                s += "\t\tSUB_TYPE: BLURAY\n";
        }
        else{
            s += "\t\tTYPE: game\n";
            s += "\t\tPLATFORM: "+((Games)proion).getConsole()+"\n";
        }

        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        
        s += "\t\tTITLE: " + proion.getTitlos() + "\n";
        s += "\t\tNAME: " + onoma_epwnymo + "\n";
        s += "\t\tDATE: " + dateFormat.format(imerominia) + "\n";
        s += "\t\tPHONE: " + thlefwno + "\n";
        s += "\t\tDAYS: " + meres_enoikiasis + "\n";
        s += "\t\tCOST: " + kostos + "\n";
                
        return s;
    }
}
