
public class Pair {
    
    public Proion proion;
    public int apothema;

    public Pair(Proion proion, int apothema) {
        this.proion = proion;
        this.apothema = apothema;
    }
}
