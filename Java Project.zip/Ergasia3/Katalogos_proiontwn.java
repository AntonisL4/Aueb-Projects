import java.util.*;

public class Katalogos_proiontwn extends ArrayList< Pair >{

    
}
