public class DVD extends Tainia{

    protected boolean neas_kukloforias;

    public DVD(String titlos, boolean neas_kukloforias, String senariografos, String actors, String skinothetis, double kostos_ana_imera, String katigoria, int etosParagogis, String etairiaParagogis) {
        super(titlos, senariografos,actors,skinothetis, kostos_ana_imera, katigoria, etosParagogis, etairiaParagogis);
        this.neas_kukloforias = neas_kukloforias;
    }

    public boolean getneas_kukloforias(){
        return neas_kukloforias;
    }

    public String toString() {
        String s = super.toString();
        if (neas_kukloforias == true){
            s+= "Neas kukloforias";}
		else
        { s+= "Palioteris kukloforias";        }
        return s;
    }

    @Override
    public String toFile() {
        String s = super.toFile();
        
        s += "\t\tSUB_TYPE: DVD\n";
        
        if (neas_kukloforias == true){
            s+= "\t\tNEW_RELEASE: yes\n";
        }
        else
        {
            s+= "\t\tNEW_RELEASE: no\n";
        }
        return s;
    }

    
}
