
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Saver {
    
    private Katalogos_enoikiasewn enoikiaseis;
    private Katalogos_proiontwn proionta;

    public Saver(Katalogos_enoikiasewn enoikiaseis, Katalogos_proiontwn proionta) {
        this.enoikiaseis = enoikiaseis;
        this.proionta = proionta;
    }
    
    public boolean saveItems(String filename)
    {
        BufferedWriter writer = null;
        
        try {
            // Anoigei to stream gia na grapsei sto arxeio
            writer = new BufferedWriter(new FileWriter(filename));
            
            writer.write("ITEM_LIST\n{\n");
            
            for (Pair pair : proionta) {
                writer.write("\tITEM\n\t{\n");
                writer.write( pair.proion.toFile() );
                writer.write( "\t\tCOPIES: "+pair.apothema+"\n" );
                writer.write("\t}\n");
            }
            
            writer.write("}");
            
            
        } catch (IOException ex) {
            return false;
        }
        finally{
            
            if( writer != null )
            {
                try {
                        writer.close();
                } catch (IOException ex) {
                    Logger.getLogger(Saver.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        return true;
    }
    
    public boolean saveRents(String filename)
    {
        BufferedWriter writer = null;
        
        try {
            // Anoigei to stream gia na grapsei sto arxeio
            writer = new BufferedWriter(new FileWriter(filename));
            
            writer.write("RENTAL_LIST\n{\n");
            
            for (Enoikiasi e : enoikiaseis) {
                writer.write("\tRENTAL\n\t{\n");
                writer.write( e.toFile() );
                writer.write("\t}\n");
            }
            
            writer.write("}");
            
            
        } catch (IOException ex) {
            return false;
        }
        finally{
            
            if( writer != null )
            {
                try {
                        writer.close();
                } catch (IOException ex) {
                    Logger.getLogger(Saver.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        return true;
    }
    
}
