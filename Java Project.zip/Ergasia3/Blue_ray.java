public class Blue_ray extends Tainia {


    public Blue_ray(String titlos, String senariografos, String actors, String skinothetis, double kostos_ana_imera, String katigoria, int etosParagogis, String etairiaParagogis) {
        super(titlos, senariografos, actors, skinothetis, kostos_ana_imera, katigoria, etosParagogis, etairiaParagogis);
    }

    @Override
    public String toFile() {
        String s = super.toFile();
        s += "\t\tSUB_TYPE: BLURAY\n";
        return s;
    }

    

}
