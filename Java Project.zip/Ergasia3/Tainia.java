public class Tainia extends Proion{

    protected String skinothetis;
    protected String senariografos;
    protected String actors;

    public Tainia(String titlos, String senariografos, String actors, String skinothetis, double kostos_ana_imera, String katigoria, int etosParagogis, String etairiaParagogis) {
        super(titlos, kostos_ana_imera, katigoria, etosParagogis, etairiaParagogis);
        this.skinothetis = skinothetis;
        this.senariografos = senariografos;
        this.actors = actors;
    }


    public String getSkinothetis() {
        return skinothetis;
    }

    public String getSenariografos() {
        return senariografos;
    }

    public String getActors() {
        return actors;
    }

    public String toString() {
        String s = super.toString();
        s += "Skinothetis: "+skinothetis+"\n";
        s += "Senariografos: "+senariografos+"\n";
        s += "Hthopioi: "+actors+"\n";
        return s;
    }
    
    @Override
    public String toFile(){
        String s = super.toFile();
        s += "\t\tITEM_TYPE: movie\n";
        s += "\t\tDIRECTOR: "+skinothetis+"\n";
        s += "\t\tWRITER: "+senariografos+"\n";
        s += "\t\tCAST: "+actors+"\n";
        return s;
    }
}