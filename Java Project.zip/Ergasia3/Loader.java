
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Loader {
    
    private Katalogos_enoikiasewn enoikiaseis;
    private Katalogos_proiontwn proionta;

    public Loader(Katalogos_enoikiasewn enoikiaseis, Katalogos_proiontwn proionta) {
        this.enoikiaseis = enoikiaseis;
        this.proionta = proionta;
    }
    
    public boolean loadItems(String filename)
    {
        BufferedReader reader = null;
        String line = null;
        
        String title = null;
        String category = null;
        String item_type = null;
        String company = null;
        double cost = 0;
        String director = null;
        String writer = null;
        String cast = null;
        String subtype = null;
        boolean newRelease = false;
        int year = -1;
        String platform = null;
        int copies = 0;
        int k = 0;
        
        
        try {
            // Anoigei to stream gia na diavasei apo to arxeio
            reader = new BufferedReader(new FileReader (filename));

            // Diavazei tin proti grammi na dei an einai idia
            line = reader.readLine();
            if( ! line.equals("ITEM_LIST") ){
                //....
                return false;
            }
            
            //reader.readLine();      // Prospernaw tin aggili
            
            while ( (line = reader.readLine()) != null ) {
                                
                if( line.trim().toUpperCase().startsWith("TITLE: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    title = line.trim().split( " ", 2 )[1];
                }
                else if( line.trim().toUpperCase().startsWith("CATEGORY: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    category = line.trim().split( " ", 2 )[1];
                }
                else if( line.trim().toUpperCase().startsWith("ITEM_TYPE: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    item_type = line.trim().split( " ", 2 )[1];
                }
                else if( line.trim().toUpperCase().startsWith("YEAR: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    // Metatropi tou String 2019 se akeraio 2019
                    year = Integer.parseInt( line.trim().split( " ", 2 )[1] );
                }
                else if( line.trim().toUpperCase().startsWith("COMPANY: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    company = line.trim().split( " ", 2 )[1] ;
                }
                else if( line.trim().toUpperCase().startsWith("DIRECTOR: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    director = line.trim().split( " ", 2 )[1] ;
                }
                else if( line.trim().toUpperCase().startsWith("COST: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    // Metatropi tou String 2019 se dekadiko 2019
                    cost = Double.parseDouble(line.trim().split( " ", 2 )[1] );
                }
                else if( line.trim().toUpperCase().startsWith("WRITER: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    writer = line.trim().split( " ", 2 )[1] ;
                }
                else if( line.trim().toUpperCase().startsWith("CAST: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    cast = line.trim().split( " ", 2 )[1] ;
                }
                else if( line.trim().toUpperCase().startsWith("SUB_TYPE: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    subtype = line.trim().split( " ", 2 )[1] ;
                }
                else if( line.trim().toUpperCase().startsWith("NEW_RELEASE: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    String temp = line.trim().split( " ", 2 )[1] ;
                    
                    if(temp.toLowerCase().equals("yes"))
                        newRelease = true;
                    else
                        newRelease = false;
                }
                else if( line.trim().toUpperCase().startsWith("COPIES: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    // Metatropi tou String 2019 se akeraio 2019
                    copies = Integer.parseInt( line.trim().split( " ", 2 )[1] );
                }
                else if( line.trim().toUpperCase().startsWith("PLATFORM: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    // Metatropi tou String 2019 se akeraio 2019
                    platform =  line.trim().split( " ", 2 )[1] ;
                }
                else if( line.trim().equals("{") ){
                    k--;
                }
                else if( line.trim().equals("}") ){
                    
                    k++;
                    
                    if( k == 0 )
                        break;
                    
                    
                    if(item_type == null || title == null || year == -1 ){
                        
                        System.out.println("Eidopoisi !");
                        continue;
                    }
                    
                    if( item_type.toLowerCase().equals("movie") ){
                        
                        if( subtype.toLowerCase().equals("dvd") ){
                            DVD dvd = new DVD(title, newRelease, writer, cast, director, cost, category, year, company);
                            proionta.add( new Pair(dvd, copies) );
                        }
                        else if( subtype.toLowerCase().equals("bluray") ){
                            Blue_ray br = new Blue_ray(title, writer, cast, director, cost, category, year, company);
                            proionta.add( new Pair(br, copies) );
                        }
                    }
                    else if( item_type.toLowerCase().equals("game") ){
                        Games game = new Games(title, platform, cost, category, year, company);
                        proionta.add( new Pair(game, copies) );
                    }

                    year = -1;
                }
            }
            
            
        } catch (IOException ex) {
            return false;
        }
        finally{
            
            if( reader != null )
            {
                try {
                        reader.close();
                } catch (IOException ex) {
                    Logger.getLogger(Saver.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        return true;
    }
    
     public boolean loadRents(String filename)
    {
        BufferedReader reader = null;
        String line = null;
        
        String title = null;
        String item_type = null;
        double cost = 0;
        String subtype = null;
        int days = -1;
        String platform = null;
        String name= null;
        Date date = null;
        String phone = null;
        int k = 0;
        
        
        try {
            // Anoigei to stream gia na diavasei apo to arxeio
            reader = new BufferedReader(new FileReader (filename));

            // Diavazei tin proti grammi na dei an einai idia
            line = reader.readLine();
            if( ! line.equals("RENTAL_LIST") ){
                //....
                return false;
            }
            
            
            while ( (line = reader.readLine()) != null ) {
                                
                if( line.trim().toUpperCase().startsWith("TITLE: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    title = line.trim().split( " ", 2 )[1];
                }
                else if( line.trim().toUpperCase().startsWith("NAME: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    name = line.trim().split( " ", 2 )[1];
                }
                else if( line.trim().toUpperCase().startsWith("PHONE: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    phone = line.trim().split( " ", 2 )[1];
                }
                else if( line.trim().toUpperCase().startsWith("DATE: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
                    date = format.parse(line.trim().split( " ", 2 )[1]);
                }
                else if( line.trim().toUpperCase().startsWith("ITEM_TYPE: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    item_type = line.trim().split( " ", 2 )[1];
                }
                else if( line.trim().toUpperCase().startsWith("DAYS: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    // Metatropi tou String 2019 se akeraio 2019
                    days = Integer.parseInt( line.trim().split( " ", 2 )[1] );
                }
                else if( line.trim().toUpperCase().startsWith("COST: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    // Metatropi tou String 2019 se dekadiko 2019
                    cost = Double.parseDouble(line.trim().split( " ", 2 )[1] );
                }
                else if( line.trim().toUpperCase().startsWith("SUB_TYPE: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    subtype = line.trim().split( " ", 2 )[1] ;
                }
                else if( line.trim().toUpperCase().startsWith("PLATFORM: ") ){
                    // Kopse me vasi to keno, kai stamata sto prwto kopsimo
                    // Metatropi tou String 2019 se akeraio 2019
                    platform =  line.trim().split( " ", 2 )[1] ;
                }
                else if( line.trim().equals("{") ){
                    k--;
                }
                else if( line.trim().equals("}") ){
                    
                    k++;
                    
                    if( k == 0 )
                        break;

                    if(item_type == null || title == null || days == -1 ){
                        
                        System.out.println("Eidopoisi !");
                        continue;
                    }
                    
                    Proion p = null;
                    for (Pair pair : proionta) {
                        if( pair.proion.getTitlos().equals( title ) )
                        {
                            p = pair.proion;
                            break;
                        }
                    }
                    
                    if( p == null ){
                        System.out.println("Den yparxei to proion enoikiasis");
                        return false;
                    }

                    Enoikiasi e = new Enoikiasi(p, name, phone, days, date, cost);
                    enoikiaseis.add(e);
                    
                    // Xanakanei -1 diladi an den vrethei days stin epomeni enoikiasi, tote den tha ftiaxei kai enoikiasi
                    days = -1;
                }
            }
            
            
        } catch (IOException ex) {
            return false;
        } catch (ParseException ex) {
            System.out.println("Lathos morfi stoixeiwn");
            return false;
        }
        finally{
            
            if( reader != null )
            {
                try {
                        reader.close();
                } catch (IOException ex) {
                    Logger.getLogger(Saver.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        return true;
    }
}
