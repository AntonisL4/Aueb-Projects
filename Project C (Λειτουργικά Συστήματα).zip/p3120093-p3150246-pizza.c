/*
 *  pizza.c
 *  LIOUSIS/PAPAILIOU 
 *  AM: 3120093/3150246
 *  May 2021
 */
#define _GNU_SOURCE       /* gettid() */

#include <stdio.h>        /* printf() */   
#include <pthread.h>      /* pthread_t, pthread_mutex_t, pthread_mutex_lock(), pthread_mutex_unlock(), 
							 pthread_cond_t, pthread_cond_init(), pthread_cond_wait(), pthread_cond_signal(), 
							 pthread_cond_broadcast(), pthread_exit(), pthread_join(), pthread_mutex_destroy(),
							 pthread_cond_destroy();*/  
#include <stdlib.h>       /* atoi(), exit(), malloc(), free(), rand_r() */
#include <unistd.h>       /* sleep(), usleep() */   
#include <math.h>         /* round() */


#include "p3120093-p3150246-pizza.h"

/*
 * definition of global variables
 */
unsigned int g_seed;   // for rand_r()
int g_cust;   // # of customers-orders


// define and initialize proper variables which are changed by each thread
int g_tel=NTEL;             // variable to hold # of available tel operators
int g_cook=NCOOK;           // variable to hold # of available cooks
int g_oven=NOVEN;           // variable to hold # of available ovens
int g_pack=1;               // variable to hold # of available packers
int g_deliverer=NDELIVERER; // variable to hold # of available deliverers
int g_revenue = 0;            // variable to hold cumulative revenue from orders
int g_successful_orders=0;    // vaiable to count successful orders
int g_cancelled_orders=0;     // variable to count disgarded orders
int *g_cust_onhold_time;      // pointer array to store time duration that customer is on hold 
int *g_order_fulfil_time;     // pointer array to store time duration that order takes until delivery-only successful orders 
int *g_order_cold_time;       // pointer array to store time duration that order takes after cooking and before delivery-only successful orders

// definition of mutex variables
pthread_mutex_t lock_tel;        // the mutex on the variable n_tel
pthread_mutex_t lock_cook;       // the mutex on the variable n_cook
pthread_mutex_t lock_oven;       // the mutex on the variable n_oven
pthread_mutex_t lock_pack;       // the mutex on the variable n_pack
pthread_mutex_t lock_deliv;      // the mutex on the variable n_deliverer
pthread_mutex_t lock_revenue;    // the mutex on the variable revenue
pthread_mutex_t lock_print;     // the mutex on the screen
// definition of condition variables
pthread_cond_t  noTelAvailable = PTHREAD_COND_INITIALIZER;   // conditional variable on the lock_tel mutex 
pthread_cond_t  noCookAvailable= PTHREAD_COND_INITIALIZER;   // conditional variable on the lock_cook mutex
pthread_cond_t  noOvenAvailable= PTHREAD_COND_INITIALIZER;   // conditional variable on the lock_oven mutex
pthread_cond_t  noPackAvailable= PTHREAD_COND_INITIALIZER;   // conditional variable on the lock_pack mutex
pthread_cond_t  noDelivAvailable=PTHREAD_COND_INITIALIZER;   // conditional variable on the lock_deliv mutex

/*
 * main function- drive program
 */
// exactly 2 command line arguments to run pizza program: g_cust and g_seed for rand_r function
int main (int argc, char** argv){	
	int i, rc;   // indexes, error codes etc 

	// check provided arguments
	
	if(argc !=3) {               // if wrong number of arguments exit
		puts("You should provide 2 arguments to run pizza program: number_of_customers and seed_of_random_number_generator");
		exit(EXIT_FAILURE);
	}
	// else read the 2 arguments	
	g_cust = atoi(argv[1]);
	if(g_cust<=0) {          // g_cust should be greater than 0
	 puts("number_of_customers must be a number greater than zero");
	 exit(EXIT_FAILURE);
	}
   	
	g_seed = atoi(argv[2]);
	display_available_resources(g_tel, g_cook, g_oven, g_pack, g_deliverer);
	
    // define array with the order thread identifiers
    pthread_t threads[g_cust];
	// array to store the ids of each order
    int thread_ids[g_cust];
	  
	// Allocate memory for previously declared arrays
    g_cust_onhold_time  = (int*) malloc( sizeof(int)*(g_cust+1) );
	if (g_cust_onhold_time == NULL) {
	    printf("Not enough memory!.Program Terminated.\n");
		exit(EXIT_FAILURE);
	}
	g_order_fulfil_time = (int *) malloc( sizeof(int)*(g_cust+1) );
	if (g_order_fulfil_time == NULL) {
		printf("Not enough memory!.Program Terminated.\n");
		exit(EXIT_FAILURE);
	}
	g_order_cold_time    = (int *) malloc( sizeof(int)*(g_cust+1) );
	if (g_order_cold_time == NULL) {
		printf("Not enough memory!.Program Terminated.\n");
		exit(EXIT_FAILURE);
	}
	// initialize thread_ids array
	for(i=0;i<g_cust;i++)
		  thread_ids[i]=0;
	 
	// Initialize the mutex  variables.
	// condition variables have been statically initialized
	
	if (pthread_mutex_init(&lock_tel,NULL) !=0) {
		printf("Error - pthread_mutex_init() failed");
		exit(EXIT_FAILURE);
	}
	if (pthread_mutex_init(&lock_cook,NULL) !=0){
		printf("Error - pthread_mutex_init() failed");
		exit(EXIT_FAILURE);
	}
	if (pthread_mutex_init(&lock_oven,NULL) !=0) {
		printf("Error - pthread_mutex_init() failed");
		exit(EXIT_FAILURE);
	}
	if (pthread_mutex_init(&lock_pack,NULL) !=0){
		printf("Error - pthread_mutex_init() failed");
		exit(EXIT_FAILURE);
	}
	if (pthread_mutex_init(&lock_deliv,NULL) !=0){
		printf("Error - pthread_mutex_init() failed");
		exit(EXIT_FAILURE);
	}
	if (pthread_mutex_init(&lock_revenue,NULL) !=0){
		printf("Error - pthread_mutex_init() failed");
		exit(EXIT_FAILURE);
	}
	if (pthread_mutex_init(&lock_print,NULL) !=0) {
		printf("Error - pthread_mutex_init() failed");
		exit(EXIT_FAILURE);
	}
	  
	printf("\n");
	// create a thread for each number of order/threads
    for(i=0;i<g_cust;i++){
	   thread_ids[i]=i+1;
	   
	   unsigned int torder=0;  // 0 value for the first order, delay of creating subsequent threads
	   
	   if(i>0){    // used to delay thread creation to simulate time duration between calls	   
			torder = rand_r(&g_seed) % (TORDERHIGH + 1 - TORDERLOW) + TORDERLOW;	
	   }
	   
	   // sleep between calls, GOFAST is defined in pizza.h
	   if(GOFAST)
	    usleep(torder*100);  // for testing purpose
       else
        sleep(torder);		
	
	   // create the thread after torder seconds
	   rc=pthread_create(&threads[i],NULL,order,&thread_ids[i]);
	   if (rc){
            printf("Error - pthread_create return code:[%d]\n",rc);
			exit(EXIT_FAILURE);
	   }
	  
    }   // threads created
	
	// stop each thread before main finishes
    for(i=0;i<g_cust;i++){
	   rc=pthread_join(threads[i],NULL);
	   if (rc){
            printf("Error - pthread_join return code:[%d]\n",rc);
			exit(EXIT_FAILURE);
	   }
    }
	
	// release mutex and conditonal variables
    pthread_mutex_destroy(&lock_tel);
	pthread_mutex_destroy(&lock_cook);
	pthread_mutex_destroy(&lock_oven);
	pthread_mutex_destroy(&lock_pack);
	pthread_mutex_destroy(&lock_deliv);
	pthread_mutex_destroy(&lock_revenue);
	pthread_mutex_destroy(&lock_print);
    
    pthread_cond_destroy(&noTelAvailable);
	pthread_cond_destroy(&noCookAvailable);
	pthread_cond_destroy(&noOvenAvailable);
	pthread_cond_destroy(&noPackAvailable);
	pthread_cond_destroy(&noDelivAvailable);
		
    // calculate and print statistics
    double sum_onhold=0,sum_fulfil=0,sum_cold=0; // variable to keep cumulative summary of diferent order stage duration
	int max_onhold=0,max_fulfil=0,max_cold=0;    // variables to keep maximum duration
	for (int x=1;x<=g_cust;x++) {
	    sum_onhold=g_cust_onhold_time[x]+sum_onhold;
	    sum_fulfil=g_order_fulfil_time[x]+sum_fulfil;
	    sum_cold=g_order_cold_time[x]+sum_cold;
	    
	    if (max_onhold<g_cust_onhold_time[x])
	        max_onhold=g_cust_onhold_time[x];
	    if (max_fulfil<g_order_fulfil_time[x])
	        max_fulfil=g_order_fulfil_time[x];
	    if (max_cold<g_order_cold_time[x])
	        max_cold=g_order_cold_time[x];
	
	}

    printf("\n------------------------------------------------\n");
	printf("|                    Συνολικά έσοδα €:%*d    |\n",MAX_WIDTH+2,g_revenue);
	printf("|           #Επιτυχημένες παραγγελίες:  %*d    |\n",MAX_WIDTH,g_successful_orders);
	printf("|           #Αποτυχημένες παραγγελίες:  %*d    |\n",MAX_WIDTH,g_cancelled_orders);
	printf("|----------------------------------------------|\n");
	
	printf("|       Μέσος χρόνος αναμονής (λεπτά):  %*.*f  |\n",MAX_WIDTH+2,MAX_WIDTH-1,(double)sum_onhold/(g_successful_orders+g_cancelled_orders));
	printf("|    Μέγιστος χρόνος αναμονής (λεπτά):  %*d    |\n",MAX_WIDTH,max_onhold);
	printf("|----------------------------------------------|\n");
	
	printf("|   Μέσος χρόνος εξυπηρέτησης (λεπτά):  %*.*f  |\n",MAX_WIDTH+2,MAX_WIDTH-1,(double)sum_fulfil/g_successful_orders);
	printf("|Μέγιστος χρόνος εξυπηρέτησης (λεπτά):  %*d    |\n",MAX_WIDTH,max_fulfil);
	printf("|----------------------------------------------|\n");
	
	printf("|      Μέσος χρόνος κρυώματος (λεπτά):  %*.*f  |\n",MAX_WIDTH+2,MAX_WIDTH-1,(double)sum_cold/g_successful_orders);
	printf("|   Μέγιστος χρόνος κρυώματος (λεπτά):  %*d    |\n",MAX_WIDTH,max_cold);
	printf("------------------------------------------------\n");
	
	// Free memory which has been reserved dynamically 
    if(g_cust_onhold_time)  free(g_cust_onhold_time);
    if(g_order_fulfil_time) free(g_order_fulfil_time);
	if(g_order_cold_time)   free(g_order_cold_time);
	
    exit(EXIT_SUCCESS);
	
}  // end of main
  
  /*
   * function order called from each thread created
   *
   */ 
    void *order(void *args){		
	  
	    
		int order_id_t = *(int*)args;   // order id
		
	    unsigned int seed_t =g_seed+gettid();   // different seed per thread
		int order_pizzas_t=0;           // number of pizzas of the order
	    unsigned int payment_delay_t=0; // delay for credit card payment, deafult =1 -> successful
	    int rc_t;                       // error code variable
		int order_successful_t = 1;  // flag to indicate if order was successful;
	    struct timespec cust_start_time_t,   // the time at which the customer calls
						order_hold_time_t,   // the time at which the tel operator answers
						order_bake_time_t,   // the time that baking of order pizzas is completed
						order_pack_time_t,   // the time at which order packing is completed
						order_deliv_time_t,  // the time at which order is delivered
						time_diff_t;                  // variable to hold the difference between 2 times
						
		 /* ετσι εχω
		    1. -  :τη στιγμη επιτυχίας/αποτυχίας της παραγγελίας
		    2. χρόνος ετοιμασίας παρ/ας  otprep_t = order_pack_time_t[g_cust] - cust_start_time_t[g_cust] :τη στιγμή που τελειωνει το πακεταρισμα
			3. χρόνος ολοκλήρωσης παρ/ας otfulfil_t = order_deliv_time_t[g_cust] - cust_start_time_t[g_cust] :τη στιγμή που ολοκληρώνεται η παράδοση
			4. revenue, successful_orders, cancelled_orders :στο τέλος
			5. χρόνος αναμονής πελάτη ctonhold_t = order_hold_time_t[g_cust] - cust_start_time_t[g_cust] :στο τέλος
			6. χρόνος εξυπηρέτησης πελάτη ctservice_t = order_deliv_time_t[g_cust] - cust_start_time_t[g_cust] :στο τέλος
			7. χρόνος κρυώματος παρ/ας otcold_t = order_deliv_time_t[g_cust] - order_pack_time_t[g_cust] :στο τέλος
			
			5. cust_onhold_time[g_cust] = ctonhold_t και θέλω avg, max - όλες    succeful_orders+cancelled_orders
			6. order_fulfil_time[g_cust] = ctservice_t και θέλω avg, max - μονο επιτυχημένες  successful_orders
			7. order_cold_time[g_cust] = otcold_t και θέλω avg, max - μόνο επιτυχημένες  successful_orders
		*/
		
		{ // Block 1-> customer call to tel operator
	      clock_gettime(CLOCK_REALTIME, &cust_start_time_t);  // get the time 
	
	      // lock the mutex in order to wait on the "tel" mutex without a problem.		
	      rc_t=pthread_mutex_lock(&lock_tel);  
			
	      while(g_tel == 0) {    // no available tel operator		
		    rc_t=pthread_cond_wait(&noTelAvailable,&lock_tel);
	      } 		
	 
		  g_tel--;
		  rc_t=pthread_mutex_unlock(&lock_tel);
				
		  clock_gettime(CLOCK_REALTIME, &order_hold_time_t); // get time

		  time_diff_t = timeDiff(cust_start_time_t, order_hold_time_t); // calculate potential hold on duration
	      int ctonhold_t = round(timespec2sec(time_diff_t)); // and convert to seconds
		  g_cust_onhold_time[order_id_t]=ctonhold_t;        // store this for the order
		} // end of Block 1
		
 		{ // Block 2-> ******tel operator gets the order******/
		  unsigned int random_number;      // variable to keep random number from generartor
		  random_number = rand_r(&seed_t);
	
		  order_pizzas_t = (random_number % (NORDERHIGH + 1 - NORDERLOW)) + NORDERLOW; // generate random number of pizzas for the order
		  random_number = rand_r(&seed_t);
		
		  payment_delay_t = (random_number % (TPAYMENTHIGH + 1 - TPAYMENTLOW)) + TPAYMENTLOW; // generate random payment time duration
		
		  // simulate card processing time
		  if(GOFAST)
		   usleep(payment_delay_t*1000);
	      else
		   sleep(payment_delay_t);
	  
		  // check if order cancelled or not, update statistic variables and print proper message		
		  if(!posibility(seed_t)) {  // with possibility 5% the order will be rejected
			  order_successful_t=0;  // set flag
			  order_pizzas_t = 0;    // set # of pizzas 0
			  g_order_fulfil_time[order_id_t]=0;
			  g_order_cold_time[order_id_t]=0;					  
		  }
			  
		  rc_t=pthread_mutex_lock(&lock_print);
		  if(!order_successful_t)
			  printf("Η παραγγελίσ με αριθμό %d απέτυχε.\n",order_id_t);
		  else 
		   if (order_pizzas_t>1)		   
		       printf("Η παραγγελία με αριθμό %d καταχωρήθηκε (%d πίτσες).\n",order_id_t,order_pizzas_t);
		   else
		   	   printf("Η παραγγελία με αριθμό %d καταχωρήθηκε (%d πίτσα).\n",order_id_t,order_pizzas_t);
		   
		  rc_t=pthread_mutex_unlock(&lock_print);
		  rc_t=pthread_mutex_lock(&lock_revenue);
		  g_revenue=g_revenue+CPIZZA*order_pizzas_t;    // increase revenue
		  g_successful_orders=g_successful_orders + order_successful_t;	  // increase number of successful orders
		  g_cancelled_orders=g_cancelled_orders + (!order_successful_t);  // increase number of cancelled orders
		  rc_t=pthread_mutex_unlock(&lock_revenue);		   
		  // release tel operator
		  rc_t = pthread_mutex_lock(&lock_tel);
		  if (rc_t) {
			printf("Error - pthread_mutex_lock return code:[%d]\n", rc_t);
			pthread_exit(&rc_t);
		   }
		  if(g_tel == 0)
		   rc_t=pthread_cond_signal(&noTelAvailable);
	   
		  g_tel++;	
		  rc_t=pthread_mutex_unlock(&lock_tel);
		} // end of Block 2
		
 		if(order_successful_t) {   // continue only if order was accepted 
 		
		 { // Block 3-> ******now prepare the order*****
		 
		   // lock the mutex in order to wait on the cooks mutex without a problem.
		 
		   rc_t = pthread_mutex_lock(&lock_cook);
		   if (rc_t) {
			printf("Error - pthread_mutex_lock return code:[%d]\n", rc_t);
			pthread_exit(&rc_t);
		   }
		   // If all the cooks are busy, then wait until one cook becomes available.
		   while (g_cook == 0) {	
         
			rc_t = pthread_cond_wait(&noCookAvailable, &lock_cook);
			if (rc_t) {	
				printf("Error - pthread_cond_wait return code:[%d]\n", rc_t);
				pthread_exit(&rc_t);
			}
		   } 		
	       g_cook = g_cook--;
		   rc_t = pthread_mutex_unlock(&lock_cook);
		   if (rc_t) {
			printf("Error - pthread_mutex_unlock return code:[%d]\n", rc_t);
			pthread_exit(&rc_t);
	 	   }
		 
	       // Simulate pizzas preparation time - order_pizzas * Tprep seconds
		 
           if(GOFAST)
		    usleep(order_pizzas_t * TPREP*1000);
	       else
		    sleep(order_pizzas_t * TPREP);
		 } // end of Block 3
		
		 { // Block 4 ***** Start baking all the pizzas of the order, by one cook, inside one oven each 
		 
		   // We lock the mutex in order to wait on the ovens mutex without a problem.
		   rc_t = pthread_mutex_lock(&lock_oven);
		   if (rc_t) {	
			printf("Error - pthread_mutex_lock return code:[%d]\n", rc_t);
			pthread_exit(&rc_t);
		   }
    
		   // Reminder: Each pizza occupies one oven 
		   // If not enough number of ovens available ovens, then wait

		   while(1) {
		    while (g_oven < order_pizzas_t){
			 rc_t = pthread_cond_wait(&noOvenAvailable, &lock_oven);
			 if (rc_t) {
				printf("Error - pthread_cond_wait return code:[%d]\n", rc_t);
				pthread_exit(&rc_t);
			 }
		    }
		    if(g_oven >= order_pizzas_t) {
		      g_oven=g_oven-order_pizzas_t;
		      rc_t = pthread_mutex_unlock(&lock_oven);
			  break;
		    }
		   }
		   // now that entire order is in the ovens you can release the cook 
		   rc_t = pthread_mutex_lock(&lock_cook);
		   if (rc_t) {
			printf("Error - pthread_mutex_lock return code:[%d]\n", rc_t);
			pthread_exit(&rc_t);
		   }
		   if (g_cook == 0) 
	         rc_t=pthread_cond_signal(&noCookAvailable);	
		   g_cook = g_cook++;		 
		   rc_t = pthread_mutex_unlock(&lock_cook);	
		 
           /* Simulate bake time for all the pizzas of the order inside the ovens */
		   if(GOFAST)
		    usleep(TBAKE*1000);
	       else
		    sleep(TBAKE);
	   
	       clock_gettime(CLOCK_REALTIME, &order_bake_time_t); // get time
		 }  // end of Block 4
			    
		 { // Block 5-> **********packaging pizzas of the order*********//
		   rc_t = pthread_mutex_lock(&lock_pack);
		   if (rc_t) {
			printf("Error - pthread_mutex_lock return code:[%d]\n", rc_t);
			pthread_exit(&rc_t);
		   }
		   // If the packer is busy, then wait until he becomes available.
		   while (g_pack == 0) {
			rc_t= pthread_cond_wait(&noPackAvailable, &lock_pack);
			if (rc_t) {	
				printf("ERROR: return code from pthread_cond_wait() is %d\n", rc_t);
				pthread_exit(&rc_t);
			}
		   }
	       g_pack = g_pack--;
		   rc_t = pthread_mutex_unlock(&lock_pack);
		 
		   // Simulate packaging time
		   if(GOFAST)
	        usleep(TPACK*1000);
	       else
		    sleep(TPACK);
		
		   // calculate preparation time
		   clock_gettime(CLOCK_REALTIME, &order_pack_time_t);
		   time_diff_t = timeDiff(cust_start_time_t, order_pack_time_t);
	       int otprep_t = round(timespec2sec(time_diff_t)); 
	       rc_t = pthread_mutex_unlock(&lock_print);
		   printf("Η παραγγελία με αριθμό %d ετοιμάστηκε σε %d λεπτά.\n",order_id_t,otprep_t);
		   rc_t = pthread_mutex_unlock(&lock_print);
		 
		   // release packer
		   rc_t = pthread_mutex_lock(&lock_pack);
		   if(g_pack==0)
		     rc_t=pthread_cond_signal(&noPackAvailable);
	       g_pack = g_pack++;
		   rc_t = pthread_mutex_unlock(&lock_pack);
		   if (rc_t) {
			printf("Error - pthread_mutex_unlock return code:[%d]\n", rc_t);
			pthread_exit(&rc_t);
		   }
		   // release ovens
		   rc_t = pthread_mutex_lock(&lock_oven);		  
	       g_oven=g_oven + order_pizzas_t;
		   rc_t=pthread_cond_broadcast(&noOvenAvailable);
		   rc_t = pthread_mutex_unlock(&lock_oven);
		   if (rc_t) {
			printf("Error - pthread_mutex_unlock return code:[%d]\n", rc_t);
			pthread_exit(&rc_t);
		   }	
		 } // end of Block 5
				
		 { // Block 6-> ***** Start delivery of ready orders ****
		
		   // We lock the mutex in order to wait on the deliv mutex without a problem.
		   rc_t = pthread_mutex_lock(&lock_deliv);
		   if (rc_t) {	
			printf("Error - pthread_mutex_unlock return code:[%d]\n", rc_t);
			pthread_exit(&rc_t);
		   }
		 
		   while (g_deliverer == 0) {
			rc_t = pthread_cond_wait(&noDelivAvailable, &lock_deliv);
			if (rc_t) {
				printf("ERROR: return code from pthread_cond_wait() is %d\n", rc_t);
				pthread_exit(&rc_t);
			}
		   }
		   g_deliverer--;
		   rc_t = pthread_mutex_unlock(&lock_deliv);
		   if (rc_t) {
			printf("ERROR: return code from pthread_mutex_unlock() is %d\n", rc_t);
			pthread_exit(&rc_t);
		   }
		 
	       // Simulate delivery time - tdel_t seconds

	       unsigned int tdel_t=0;     // variable to store time deliverer needs to deliver the order
           unsigned int randdel_t;	  // random_number
	   
	       randdel_t = rand_r(&seed_t);
		   tdel_t = (randdel_t % (TDELHIGH + 1 - TDELLOW)) + TDELLOW;
		 	
	       if(GOFAST)
	        usleep(tdel_t*1000);
		   else
            sleep(tdel_t);	
	  
           // calculate fulfil time duration
		   clock_gettime(CLOCK_REALTIME, &order_deliv_time_t); // get time 
		
		   time_diff_t = timeDiff(cust_start_time_t, order_deliv_time_t);
	       int ctservice_t = round(timespec2sec(time_diff_t));    // variable to keep order fulfilment time duration
		   g_order_fulfil_time[order_id_t]=ctservice_t;
		   // calculate cold duratio n
		   time_diff_t = timeDiff(order_pack_time_t, order_deliv_time_t);
	       int otcold_t = round(timespec2sec(time_diff_t));  // variable to keep cold time duration
		   g_order_cold_time[order_id_t]= otcold_t;
		  
	       rc_t = pthread_mutex_lock(&lock_print);
		   printf("Η παραγγελία με αριθμό %d παραδόθηκε σε %d λεπτά.\n",order_id_t,ctservice_t);
		   rc_t = pthread_mutex_unlock(&lock_print);
		 
		   // Simulate deliverer return time
	       if(GOFAST)
	        usleep(tdel_t*1000);
		   else
            sleep(tdel_t);	
	  
	       rc_t = pthread_mutex_lock(&lock_deliv);
		   if (rc_t) {	
			printf("ERROR: return code from pthread_mutex_lock() on \"ovens\" is %d\n", rc_t);
			pthread_exit(&rc_t);
		   }	
		   if(g_deliverer==0)
		     rc_t=pthread_cond_signal(&noDelivAvailable);
		   g_deliverer++;
		   rc_t = pthread_mutex_unlock(&lock_deliv);
		   if (rc_t) {
			printf("ERROR: return code from pthread_mutex_unlock() is %d\n", rc_t);
			pthread_exit(&rc_t);
		   }
		 } // end of Block 6
		  
	   }  // end if(!order_cancelled)
		
		pthread_exit(NULL);
    } // end of function order   
   
    void display_available_resources(int tel,int cook, int oven,int pack, int deliverer){
		printf("\n");
		printf("    Διαθέσιμοι πόροι, σταθερές & παράμετροι\n");
	    printf("   ------------------------------------------\n");
	    printf("   |    Τηλεφωνητές:  %2d |    Torderlow: %2d |\n",tel,TORDERLOW);
	    printf("   |         Ψήστες:  %2d |   Torderhigh: %2d |\n",cook,TORDERHIGH);
	    printf("   |        Φούρνοι:  %2d |    Norderlow: %2d |\n",oven, NORDERLOW);
		printf("   |    Συσκευαστές:  %2d |   Norderhigh: %2d |\n",pack,NORDERHIGH);
	    printf("   |      Διανομείς:  %2d |  Tpaymentlow: %2d |\n",deliverer,TPAYMENTLOW);
	    printf("   |---------------------| Tpaymenthigh: %2d |\n",TPAYMENTHIGH);
		printf("   |         Κόστος      |       Tprep : %2d |\n",TPREP);
		printf("   |         πίτσας:  %2d |        Tbake: %2d |\n",CPIZZA,TBAKE);
		printf("   |---------------------|        Tpack: %2d |\n",TPACK);
		printf("   |        Πελάτες: %3d |      Tdellow: %2d |\n",g_cust,TDELLOW);
		printf("   | Αρχικός σπόρος:%4d |     Tdelhigh: %2d |\n",g_seed,TDELHIGH);
		printf("   ------------------------------------------");		
	    printf("\n");
    }
	
    // function to return 0 with 5% posibility
	// returns int 1 or 0
    int posibility(unsigned int seed){
	    int random = (rand_r(&seed) %100)+1;
        if(random<=95) return 1; else return 0;
    }
	
	// function to calculate difference between 2 timespec times
	// returns timespec
	struct timespec timeDiff(struct timespec start,struct timespec end) {
			struct timespec temp;

			if ((end.tv_nsec-start.tv_nsec)<0)
			{
				temp.tv_sec = end.tv_sec-start.tv_sec-1;
				temp.tv_nsec = BILLION+end.tv_nsec-start.tv_nsec;
			}
			else 
			{
				temp.tv_sec = end.tv_sec-start.tv_sec;
				temp.tv_nsec = end.tv_nsec-start.tv_nsec;
			}
	
		return temp;
	}
	
	// function to convert timespec time to seconds
	// returns double
	double timespec2sec(struct timespec t){
		return ((double)(t.tv_sec) + ((double)(t.tv_nsec)/BILLION));
	}
	
